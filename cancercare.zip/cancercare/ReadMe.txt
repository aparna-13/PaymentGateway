Web And Mobile Development Internship

Name : Aparna. S

TASK #3 - Payment Gateway Integration

The submitted project is a website that collects donation for cancer patients, built using:

HTML: The language that allows the user to create and structure sections, paragraphs, headings, links, and blockquotes for web pages and applications.

CSS: The language that is used for describing the presentation of Web pages, including colors, layout, and fonts. And also allows one to adapt the presentation to different types of devices, such as large screens and small screens.

Bootstrap: An open-source, free to use, potent front-end framework that features numerous HTML and CSS templates for UI interface elements such as buttons and forms.

The payment gateway is built using the help of instamojo.
Instamojo is positioned as the “simplest payment solution” where it has removed barriers of entry like technical know-how, upfront costs, providing access to distribution channels on web & mobile through various up-selling & cross-selling e-commerce tools & features; thus boosting time to market for small businesses to sell & collect payments, manage & grow rapidly.